module.exports = {
    Task: require('./Task'),
    Icon: require('./Icon'),
    User: require('./User'),
    salt: require('./hash'),
    Document: require('./Document')
}